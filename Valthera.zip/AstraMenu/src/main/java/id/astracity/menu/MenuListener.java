package id.astracity.menu;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuListener implements Listener {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final AstraMenu plugin;
    private final NamespacedKey menuItemKey;
    private final NamespacedKey contactKey;
    private final NamespacedKey waypointKey;

    /** pengirim -> penerima, menunggu ketikan pesan di chat */
    private final Map<UUID, UUID> pendingMessage = new ConcurrentHashMap<>();
    private final Set<UUID> dnd = ConcurrentHashMap.newKeySet();

    public MenuListener(AstraMenu plugin) {
        this.plugin = plugin;
        this.menuItemKey = new NamespacedKey(plugin, "menu_item");
        this.contactKey = new NamespacedKey(plugin, "contact_uuid");
        this.waypointKey = new NamespacedKey(plugin, "waypoint_id");
    }

    // ------------------------------------------------------------------ helper

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    private static Component mm(String s) {
        return MM.deserialize("<!italic>" + s);
    }

    private void later(Runnable r) {
        Bukkit.getScheduler().runTask(plugin, r);
    }

    private ItemStack icon(String key, Material fallback, String name, String... lore) {
        Material m = Material.matchMaterial(cfg().getString("icons." + key + ".material", fallback.name()));
        if (m == null) m = fallback;
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(mm(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(mm(s));
            meta.lore(l);
        }
        int model = cfg().getInt("icons." + key + ".model-data", 0);
        if (model > 0) meta.setCustomModelData(model);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack filler() {
        ItemStack it = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(" "));
        it.setItemMeta(meta);
        return it;
    }

    private Inventory create(MenuHolder.Type type, int size, String titleKey, boolean fill) {
        MenuHolder holder = new MenuHolder(type);
        Inventory inv = Bukkit.createInventory(holder, size,
                MM.deserialize(cfg().getString("titles." + titleKey, "Menu")));
        holder.setInventory(inv);
        if (fill) {
            ItemStack f = filler();
            for (int i = 0; i < size; i++) inv.setItem(i, f);
        }
        return inv;
    }

    private void click(Player p) {
        p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1f);
    }

    private void giveOrDrop(Player p, ItemStack item) {
        p.getInventory().addItem(item).values()
                .forEach(left -> p.getWorld().dropItemNaturally(p.getLocation(), left));
    }

    // -------------------------------------------------------------- buka menu

    public void openMain(Player p) {
        Inventory inv = create(MenuHolder.Type.MAIN, 27, "main", true);
        inv.setItem(11, icon("phone", Material.PAPER, "<aqua><bold>Ponsel", "<gray>Kontak, pesan, GPS, jam."));
        inv.setItem(13, icon("bag", Material.CHEST, "<gold><bold>Tas", "<gray>Penyimpanan barang pribadimu."));
        inv.setItem(15, icon("map", Material.FILLED_MAP, "<green><bold>Peta & GPS", "<gray>Pilih tujuan, arah tampil di layar."));
        p.openInventory(inv);
    }

    public void openPhone(Player p) {
        Inventory inv = create(MenuHolder.Type.PHONE, 27, "phone", true);
        inv.setItem(10, icon("contacts", Material.PLAYER_HEAD, "<aqua>Kontak & Pesan",
                "<gray>Pemain online: <white>" + (Bukkit.getOnlinePlayers().size() - 1),
                "<gray>Kirim pesan atau panggil."));
        inv.setItem(12, icon("map", Material.FILLED_MAP, "<green>GPS", "<gray>Pilih tujuan di peta."));
        if (dnd.contains(p.getUniqueId())) {
            inv.setItem(14, icon("dnd-on", Material.RED_DYE, "<red>Jangan Ganggu: AKTIF", "<gray>Klik untuk menonaktifkan."));
        } else {
            inv.setItem(14, icon("dnd-off", Material.LIME_DYE, "<green>Jangan Ganggu: MATI", "<gray>Klik untuk mengaktifkan."));
        }
        inv.setItem(16, icon("clock", Material.CLOCK, "<yellow>Jam",
                "<gray>Dalam game: <white>" + gameTime(p.getWorld()),
                "<gray>Waktu nyata: <white>" + realTime()));
        inv.setItem(22, icon("back", Material.ARROW, "<red>Kembali"));
        p.openInventory(inv);
    }

    public void openContacts(Player p) {
        Inventory inv = create(MenuHolder.Type.CONTACTS, 54, "contacts", true);
        List<Player> list = new ArrayList<>(Bukkit.getOnlinePlayers());
        list.remove(p);
        list.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));

        int slot = 0;
        for (Player t : list) {
            if (slot >= 45) break;
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta sm = (SkullMeta) head.getItemMeta();
            sm.setOwningPlayer(t);
            sm.displayName(mm("<white>" + t.getName()));
            sm.lore(List.of(
                    mm("<gray>Klik kiri: kirim pesan"),
                    mm("<gray>Klik kanan: panggil"),
                    dnd.contains(t.getUniqueId()) ? mm("<red>Sedang Jangan Ganggu") : mm("<green>Tersedia")));
            sm.getPersistentDataContainer().set(contactKey, PersistentDataType.STRING, t.getUniqueId().toString());
            head.setItemMeta(sm);
            inv.setItem(slot++, head);
        }
        if (list.isEmpty()) {
            inv.setItem(22, icon("empty", Material.BARRIER, "<red>Tidak ada pemain lain online"));
        }
        inv.setItem(49, icon("back", Material.ARROW, "<red>Kembali"));
        p.openInventory(inv);
    }

    public void openMap(Player p) {
        Inventory inv = create(MenuHolder.Type.MAP, 54, "map", true);
        ConfigurationSection wps = cfg().getConfigurationSection("waypoints");
        boolean canTp = canTeleport(p);
        int slot = 0;
        if (wps != null) {
            for (String id : wps.getKeys(false)) {
                if (slot >= 45) break;
                Location loc = waypointLocation(id);
                ConfigurationSection s = wps.getConfigurationSection(id);
                if (loc == null || s == null) {
                    plugin.getLogger().warning("Waypoint '" + id + "' tidak valid (dunia tidak ditemukan?).");
                    continue;
                }
                Material m = Material.matchMaterial(s.getString("material", "COMPASS"));
                if (m == null) m = Material.COMPASS;
                ItemStack it = new ItemStack(m);
                ItemMeta meta = it.getItemMeta();
                meta.displayName(mm(s.getString("name", id)));
                List<Component> lore = new ArrayList<>();
                if (loc.getWorld().equals(p.getWorld())) {
                    lore.add(mm("<gray>Jarak: <white>" + (int) horizontalDistance(p.getLocation(), loc) + " m"));
                } else {
                    lore.add(mm("<red>Berada di dunia lain"));
                }
                lore.add(mm("<yellow>Klik kiri: tandai di GPS"));
                if (canTp) lore.add(mm("<yellow>Klik kanan: teleport"));
                meta.lore(lore);
                meta.getPersistentDataContainer().set(waypointKey, PersistentDataType.STRING, id);
                it.setItemMeta(meta);
                inv.setItem(slot++, it);
            }
        }
        inv.setItem(45, icon("back", Material.ARROW, "<red>Kembali"));
        if (plugin.gps().isActive(p.getUniqueId())) {
            inv.setItem(49, icon("gps-off", Material.BARRIER, "<red>Matikan GPS"));
        }
        p.openInventory(inv);
    }

    public void openBag(Player p) {
        p.closeInventory(); // pastikan tas lama tersimpan dulu sebelum dimuat ulang
        int rows = Math.max(1, Math.min(6, cfg().getInt("bag.rows", 3)));
        MenuHolder holder = new MenuHolder(MenuHolder.Type.BAG);
        Inventory inv = Bukkit.createInventory(holder, rows * 9,
                MM.deserialize(cfg().getString("titles.bag", "Tas")));
        holder.setInventory(inv);

        ItemStack[] stored = plugin.bags().load(p.getUniqueId());
        for (int i = 0; i < stored.length; i++) {
            ItemStack it = stored[i];
            if (it == null || it.getType().isAir()) continue;
            if (i < inv.getSize()) inv.setItem(i, it);
            else giveOrDrop(p, it); // baris tas dikurangi di config
        }
        p.openInventory(inv);
    }

    // ----------------------------------------------------------------- util

    private String gameTime(World w) {
        long t = w.getTime();
        int h = (int) ((t / 1000 + 6) % 24);
        int m = (int) ((t % 1000) * 60 / 1000);
        return String.format("%02d:%02d", h, m);
    }

    private String realTime() {
        ZoneId zone;
        try {
            zone = ZoneId.of(cfg().getString("timezone", "Asia/Jakarta"));
        } catch (Exception e) {
            zone = ZoneId.systemDefault();
        }
        return LocalTime.now(zone).format(DateTimeFormatter.ofPattern("HH:mm"));
    }

    private double horizontalDistance(Location a, Location b) {
        double dx = a.getX() - b.getX();
        double dz = a.getZ() - b.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    private boolean canTeleport(Player p) {
        return cfg().getBoolean("map.allow-teleport", false) && p.hasPermission("astramenu.teleport");
    }

    private Location waypointLocation(String id) {
        ConfigurationSection s = cfg().getConfigurationSection("waypoints." + id);
        if (s == null) return null;
        World w = Bukkit.getWorld(s.getString("world", "world"));
        if (w == null) return null;
        return new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw", 0), (float) s.getDouble("pitch", 0));
    }

    // ----------------------------------------------------------- item ponsel

    private ItemStack createMenuItem() {
        ItemStack it = icon("menu-item", Material.PAPER, "<aqua><bold>Ponsel", "<gray>Klik kanan untuk membuka menu.");
        ItemMeta meta = it.getItemMeta();
        meta.getPersistentDataContainer().set(menuItemKey, PersistentDataType.BYTE, (byte) 1);
        it.setItemMeta(meta);
        return it;
    }

    private boolean isMenuItem(ItemStack it) {
        return it != null && it.hasItemMeta()
                && it.getItemMeta().getPersistentDataContainer().has(menuItemKey, PersistentDataType.BYTE);
    }

    public void giveMenuItem(Player p) {
        if (!cfg().getBoolean("menu-item.enabled", true)) return;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.getSize(); i++) {
            if (isMenuItem(inv.getItem(i))) inv.setItem(i, null);
        }
        int slot = Math.max(0, Math.min(8, cfg().getInt("menu-item.slot", 8)));
        ItemStack old = inv.getItem(slot);
        inv.setItem(slot, createMenuItem());
        if (old != null && !old.getType().isAir()) giveOrDrop(p, old);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> giveMenuItem(p), 5L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> giveMenuItem(p), 2L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        e.getDrops().removeIf(this::isMenuItem);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        pendingMessage.remove(id);
        dnd.remove(id);
        plugin.gps().stop(id);
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (!isMenuItem(e.getItem())) return;
        e.setCancelled(true);
        openMain(e.getPlayer());
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (isMenuItem(e.getItemDrop().getItemStack())) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (!cfg().getBoolean("swap-key.enabled", true)) return;
        Player p = e.getPlayer();
        if (cfg().getBoolean("swap-key.require-sneak", false) && !p.isSneaking()) return;
        e.setCancelled(true);
        openMain(p);
    }

    // ------------------------------------------------------------- klik menu

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;

        // item ponsel tidak boleh dipindah / dimasukkan ke wadah apa pun
        boolean hotbarSwap = e.getClick() == ClickType.NUMBER_KEY && e.getHotbarButton() >= 0
                && isMenuItem(p.getInventory().getItem(e.getHotbarButton()));
        if (isMenuItem(e.getCurrentItem()) || isMenuItem(e.getCursor()) || hotbarSwap) {
            e.setCancelled(true);
            return;
        }

        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder holder)) return;
        if (holder.getType() == MenuHolder.Type.BAG) return; // tas bebas diisi

        e.setCancelled(true);
        if (e.getClickedInventory() != top) return;
        ItemStack item = e.getCurrentItem();
        if (item == null || item.getType().isAir()) return;

        int slot = e.getSlot();
        ClickType ct = e.getClick();
        switch (holder.getType()) {
            case MAIN -> handleMain(p, slot);
            case PHONE -> handlePhone(p, slot);
            case CONTACTS -> handleContacts(p, slot, item, ct);
            case MAP -> handleMap(p, slot, item, ct);
            default -> { }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder h
                && h.getType() != MenuHolder.Type.BAG) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof MenuHolder h && h.getType() == MenuHolder.Type.BAG) {
            plugin.bags().save(e.getPlayer().getUniqueId(), h.getInventory().getContents());
        }
    }

    private void handleMain(Player p, int slot) {
        switch (slot) {
            case 11 -> { click(p); later(() -> openPhone(p)); }
            case 13 -> { click(p); later(() -> openBag(p)); }
            case 15 -> { click(p); later(() -> openMap(p)); }
            default -> { }
        }
    }

    private void handlePhone(Player p, int slot) {
        switch (slot) {
            case 10 -> { click(p); later(() -> openContacts(p)); }
            case 12 -> { click(p); later(() -> openMap(p)); }
            case 14 -> {
                click(p);
                UUID id = p.getUniqueId();
                if (!dnd.add(id)) dnd.remove(id);
                later(() -> openPhone(p));
            }
            case 16 -> later(() -> openPhone(p)); // segarkan jam
            case 22 -> { click(p); later(() -> openMain(p)); }
            default -> { }
        }
    }

    private void handleContacts(Player p, int slot, ItemStack item, ClickType ct) {
        if (slot == 49) {
            click(p);
            later(() -> openPhone(p));
            return;
        }
        String raw = item.getItemMeta().getPersistentDataContainer().get(contactKey, PersistentDataType.STRING);
        if (raw == null) return;
        Player target = Bukkit.getPlayer(UUID.fromString(raw));
        if (target == null) {
            p.sendMessage(mm("<red>Pemain sudah offline."));
            later(() -> openContacts(p));
            return;
        }
        click(p);
        if (ct.isLeftClick()) startMessage(p, target);
        else if (ct.isRightClick()) call(p, target);
    }

    private void handleMap(Player p, int slot, ItemStack item, ClickType ct) {
        if (slot == 45) {
            click(p);
            later(() -> openMain(p));
            return;
        }
        if (slot == 49 && plugin.gps().isActive(p.getUniqueId())) {
            click(p);
            plugin.gps().stop(p);
            p.sendMessage(mm("<gray>GPS dimatikan."));
            later(() -> openMap(p));
            return;
        }
        String id = item.getItemMeta().getPersistentDataContainer().get(waypointKey, PersistentDataType.STRING);
        if (id == null) return;
        Location loc = waypointLocation(id);
        if (loc == null) return;
        String name = cfg().getString("waypoints." + id + ".name", id);

        click(p);
        if (ct.isRightClick()) {
            if (!canTeleport(p)) {
                p.sendMessage(mm("<red>Teleport tidak tersedia."));
                return;
            }
            later(() -> {
                p.closeInventory();
                p.teleportAsync(loc);
            });
        } else if (ct.isLeftClick()) {
            later(() -> {
                p.closeInventory();
                plugin.gps().start(p, name, loc);
            });
        }
    }

    // ------------------------------------------------------- pesan & panggilan

    private boolean blockedByDnd(Player from, Player to) {
        if (dnd.contains(to.getUniqueId()) && !from.hasPermission("astramenu.dnd.bypass")) {
            from.sendMessage(mm("<red>" + to.getName() + " sedang mode Jangan Ganggu."));
            return true;
        }
        return false;
    }

    private void startMessage(Player p, Player target) {
        if (blockedByDnd(p, target)) return;
        UUID id = p.getUniqueId();
        UUID tid = target.getUniqueId();
        later(p::closeInventory);
        pendingMessage.put(id, tid);
        p.sendMessage(mm("<aqua>[Ponsel] <gray>Ketik pesanmu untuk <white>" + target.getName()
                + "<gray> di chat. Ketik <white>batal<gray> untuk membatalkan."));
        Bukkit.getScheduler().runTaskLater(plugin, () -> pendingMessage.remove(id, tid), 20L * 60);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        UUID target = pendingMessage.remove(e.getPlayer().getUniqueId());
        if (target == null) return;
        e.setCancelled(true);
        Player sender = e.getPlayer();
        String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        later(() -> {
            if (text.equalsIgnoreCase("batal")) {
                sender.sendMessage(mm("<gray>Pesan dibatalkan."));
                return;
            }
            Player t = Bukkit.getPlayer(target);
            if (t == null) {
                sender.sendMessage(mm("<red>Pemain sudah offline."));
                return;
            }
            sendSms(sender, t, text);
        });
    }

    public void sendSms(Player from, Player to, String raw) {
        if (blockedByDnd(from, to)) return;
        String text = raw.length() > 200 ? raw.substring(0, 200) : raw;
        if (text.isBlank()) return;
        Component body = Component.text(text, NamedTextColor.WHITE);
        to.sendMessage(mm("<aqua>[SMS] <white>" + from.getName() + " <gray>» ").append(body));
        from.sendMessage(mm("<aqua>[SMS] <gray>ke <white>" + to.getName() + " <gray>» ").append(body));
        to.playSound(to.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
    }

    private void call(Player from, Player to) {
        if (blockedByDnd(from, to)) return;
        later(from::closeInventory);
        from.sendMessage(mm("<aqua>[Ponsel] <gray>Memanggil <white>" + to.getName() + "<gray>..."));
        to.sendMessage(mm("<aqua>[Ponsel] <white>" + from.getName()
                + " <gray>memanggilmu. Balas dengan <white>/pesan " + from.getName() + " [teks]"));
        to.showTitle(Title.title(
                MM.deserialize("<aqua>Panggilan Masuk"),
                MM.deserialize("<white>" + from.getName()),
                Title.Times.times(Duration.ofMillis(200), Duration.ofSeconds(3), Duration.ofMillis(500))));
        new BukkitRunnable() {
            int count = 0;

            @Override
            public void run() {
                if (count++ >= 5 || !to.isOnline()) {
                    cancel();
                    return;
                }
                to.playSound(to.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1.2f);
            }
        }.runTaskTimer(plugin, 0L, 15L);
    }
}
