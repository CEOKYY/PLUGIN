package id.astracity.menu;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.List;

public final class AstraMenu extends JavaPlugin {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private BagManager bags;
    private GpsManager gps;
    private MenuListener menus;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        bags = new BagManager(this);
        gps = new GpsManager(this);
        menus = new MenuListener(this);
        getServer().getPluginManager().registerEvents(menus, this);

        for (String name : List.of("menu", "ponsel", "tas", "peta", "gps", "pesan", "astramenu")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) pc.setExecutor(this);
        }
        for (Player p : getServer().getOnlinePlayers()) menus.giveMenuItem(p);
    }

    @Override
    public void onDisable() {
        for (Player p : getServer().getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder h
                    && h.getType() == MenuHolder.Type.BAG) {
                bags.save(p.getUniqueId(), h.getInventory().getContents());
            }
        }
        if (gps != null) gps.stopAll();
    }

    public BagManager bags() { return bags; }
    public GpsManager gps() { return gps; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd,
                             @NotNull String label, @NotNull String[] args) {
        String name = cmd.getName().toLowerCase();

        if (name.equals("astramenu")) {
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("astramenu.admin")) {
                    sender.sendMessage(MM.deserialize("<red>Kamu tidak punya izin."));
                    return true;
                }
                reloadConfig();
                sender.sendMessage(MM.deserialize("<green>AstraMenu: config dimuat ulang."));
            } else {
                sender.sendMessage(MM.deserialize("<gray>Gunakan <white>/astramenu reload"));
            }
            return true;
        }

        if (!(sender instanceof Player p)) {
            sender.sendMessage("Perintah ini hanya untuk pemain.");
            return true;
        }

        switch (name) {
            case "menu" -> menus.openMain(p);
            case "ponsel" -> menus.openPhone(p);
            case "tas" -> menus.openBag(p);
            case "peta" -> menus.openMap(p);
            case "gps" -> {
                if (args.length > 0 && args[0].equalsIgnoreCase("batal")) {
                    gps.stop(p);
                    p.sendMessage(MM.deserialize("<gray>GPS dimatikan."));
                } else {
                    menus.openMap(p);
                }
            }
            case "pesan" -> {
                if (args.length < 2) {
                    p.sendMessage(MM.deserialize("<red>Pemakaian: /pesan [pemain] [teks]"));
                    return true;
                }
                Player target = getServer().getPlayerExact(args[0]);
                if (target == null) {
                    p.sendMessage(MM.deserialize("<red>Pemain tidak ditemukan / offline."));
                    return true;
                }
                menus.sendSms(p, target, String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
            }
            default -> { }
        }
        return true;
    }
}
