package id.astracity.menu;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** GPS: panah arah + jarak di action bar sampai pemain tiba di tujuan. */
public final class GpsManager {

    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final String[] ARROWS = {"↑", "↗", "→", "↘", "↓", "↙", "←", "↖"};

    private final AstraMenu plugin;
    private final Map<UUID, BukkitTask> tasks = new HashMap<>();

    public GpsManager(AstraMenu plugin) {
        this.plugin = plugin;
    }

    public boolean isActive(UUID id) {
        return tasks.containsKey(id);
    }

    public void start(Player p, String name, Location target) {
        UUID id = p.getUniqueId();
        stop(id);
        double radius = plugin.getConfig().getDouble("gps.arrive-radius", 8);
        p.setCompassTarget(target);
        p.sendMessage(MM.deserialize("<green>GPS aktif menuju <white>" + name + "<green>. Ikuti panah di layar."));
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            Player pl = Bukkit.getPlayer(id);
            if (pl == null) {
                stop(id);
                return;
            }
            tick(pl, name, target, radius);
        }, 0L, 10L);
        tasks.put(id, task);
    }

    private void tick(Player p, String name, Location target, double radius) {
        Location loc = p.getLocation();
        if (!loc.getWorld().equals(target.getWorld())) {
            p.sendActionBar(MM.deserialize("<red>GPS: tujuan ada di dunia lain (" + target.getWorld().getName() + ")"));
            return;
        }
        double dx = target.getX() - loc.getX();
        double dz = target.getZ() - loc.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        if (dist <= radius) {
            stop(p.getUniqueId());
            p.setCompassTarget(p.getWorld().getSpawnLocation());
            p.showTitle(Title.title(MM.deserialize("<green>Tiba di tujuan"), MM.deserialize("<white>" + name)));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            return;
        }

        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double diff = targetYaw - loc.getYaw();
        diff = ((diff + 540) % 360) - 180; // -180..180, positif = tujuan di kanan
        int idx = (int) Math.round(diff / 45.0);
        idx = ((idx % 8) + 8) % 8;

        p.sendActionBar(MM.deserialize("<green>GPS <gray>» <white>" + name
                + " <gray>| <yellow>" + (int) dist + " m <white>" + ARROWS[idx]));
    }

    public void stop(UUID id) {
        BukkitTask t = tasks.remove(id);
        if (t != null) t.cancel();
    }

    public void stop(Player p) {
        stop(p.getUniqueId());
    }

    public void stopAll() {
        for (UUID id : new ArrayList<>(tasks.keySet())) stop(id);
    }
}
