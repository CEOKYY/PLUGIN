package id.astracity.menu;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

/** Menyimpan isi tas tiap pemain ke file bags/<uuid>.dat */
public final class BagManager {

    private final AstraMenu plugin;
    private final File dir;

    public BagManager(AstraMenu plugin) {
        this.plugin = plugin;
        this.dir = new File(plugin.getDataFolder(), "bags");
        if (!dir.exists() && !dir.mkdirs()) {
            plugin.getLogger().warning("Gagal membuat folder bags.");
        }
    }

    public ItemStack[] load(UUID id) {
        File f = new File(dir, id + ".dat");
        if (!f.exists()) return new ItemStack[0];
        try {
            return ItemStack.deserializeItemsAsBytes(Files.readAllBytes(f.toPath()));
        } catch (IOException | RuntimeException e) {
            plugin.getLogger().severe("File tas " + id + " rusak, dipindah ke .corrupt: " + e.getMessage());
            //noinspection ResultOfMethodCallIgnored
            f.renameTo(new File(dir, id + ".dat.corrupt"));
            return new ItemStack[0];
        }
    }

    public void save(UUID id, ItemStack[] items) {
        ItemStack[] safe = new ItemStack[items.length];
        for (int i = 0; i < items.length; i++) {
            safe[i] = items[i] == null ? new ItemStack(Material.AIR) : items[i];
        }
        try {
            Path target = new File(dir, id + ".dat").toPath();
            Path tmp = new File(dir, id + ".dat.tmp").toPath();
            Files.write(tmp, ItemStack.serializeItemsAsBytes(safe));
            Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException | RuntimeException e) {
            plugin.getLogger().severe("Gagal menyimpan tas " + id + ": " + e.getMessage());
        }
    }
}
